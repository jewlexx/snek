use std::collections::VecDeque;

use bevy::{
    diagnostic::{EntityCountDiagnosticsPlugin, FrameTimeDiagnosticsPlugin},
    prelude::*,
    sprite::MaterialMesh2dBundle,
};
use bevy_editor_pls::prelude::*;

// Ideas
// - When moving, simply prepend a Vec2 to the front of the coords vector, becoming the new head, and shift all the other coordinates up one
// - Use fixed time interval to limit framerate so snake doesn't move too fast
// - https://www.reddit.com/r/bevy/comments/qeicc1/comment/hhttbw4/?utm_source=share&utm_medium=web2x&context=3

const WINDOW_WIDTH: f32 = 1024.;
const WINDOW_HEIGHT: f32 = 1024.;

// TODO: Use entities for snake and board

#[derive(Debug, Clone, Component)]
struct Snake {
    coords: VecDeque<Vec2>,
    length: u64,
}

impl Default for Snake {
    fn default() -> Self {
        Self {
            coords: [Vec2::new(5., 5.)].into(),
            length: 1,
        }
    }
}

#[derive(Debug, Clone, Component)]
struct Board {
    width: i32,
    height: i32,
    snake: Snake,
}

impl Default for Board {
    fn default() -> Self {
        Self {
            width: 10,
            height: 10,
            snake: Snake::default(),
        }
    }
}

fn initialize_window(mut windows: ResMut<Windows>) {
    for window in windows.iter_mut() {
        window.set_title(String::from("Yay, I'm a window!"));
        window.set_resolution(WINDOW_WIDTH, WINDOW_HEIGHT);
        window.set_resizable(false);
    }
}

// fn setup_assets()

fn render_board(
    mut commands: Commands,
    mut meshes: ResMut<Assets<Mesh>>,
    mut materials: ResMut<Assets<ColorMaterial>>,
    asset_server: Res<AssetServer>,
) {
    let board = Board::default();

    let tile_texture = asset_server.load("tile.png");
    let snake_body_texture = asset_server.load("snake_body.png");

    let tile_material = materials.add(ColorMaterial {
        texture: Some(tile_texture),
        ..default()
    });

    let snake_material = materials.add(ColorMaterial {
        texture: Some(snake_body_texture),
        ..default()
    });

    // for y in 0..board.height {
    //     for x in 0..board.width {
    //         let coord = Vec2::new(x as f32, y as f32);

    //         let is_snake = board
    //             .snake
    //             .coords
    //             .iter()
    //             .any(|snake_coord| snake_coord == &coord);

    //         commands.spawn(MaterialMesh2dBundle {
    //             mesh: meshes
    //                 .add(shape::Box::new(WINDOW_WIDTH / 10., WINDOW_HEIGHT / 10., 1.).into())
    //                 .into(),
    //             material: tile_material.clone(),
    //             transform: Transform::from_xyz(coord.x * 100., coord.y * 100., 0.),
    //             ..default()
    //         });
    //     }
    // }

    // Spawn board component
    commands.spawn(board);

    // Initialize camera
    commands.spawn(Camera2dBundle::default());

    commands.spawn(Sprite {
        color: Color::RED,
        custom_size: Some(Vec2::new(10., 10.)),
        ..default()
    });
}

fn main() {
    App::new()
        .add_plugins(DefaultPlugins)
        .add_plugin(EditorPlugin)
        .add_plugin(EntityCountDiagnosticsPlugin)
        .add_plugin(FrameTimeDiagnosticsPlugin)
        .add_startup_system(render_board)
        .add_startup_system(initialize_window.after(render_board))
        .run();
}
